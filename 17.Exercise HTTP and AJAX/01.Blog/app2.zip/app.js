function attachEvents() {
    const loadPostsButton = document.getElementById('btnLoadPosts');
    loadPostsButton.addEventListener('click', async () => {
        const selectPosts = document.getElementById('posts');
        const postsUrl = 'http://localhost:3030/jsonstore/blog/posts';

        selectPosts.innerHTML = '';

        try {
            const response = await fetch(postsUrl);
            if (!response.ok) {
                throw new Error('Error fetching posts');
            }

            const postsData = await response.json();

            Object.values(postsData).forEach(postData => {
                const optionElement = document.createElement('option');
                optionElement.value = postData.id;
                optionElement.textContent = postData.title;
                selectPosts.appendChild(optionElement);
            });
        } catch (error) {
            console.error('Failed to load posts:', error);
        }
    });

    const viewPostsButton = document.getElementById('btnViewPost');
    viewPostsButton.addEventListener('click', async () => {
        const postTitle = document.getElementById('post-title');
        const postBody = document.getElementById('post-body');
        const postComments = document.getElementById('post-comments');
        const selectedPostId = document.getElementById('posts').value;
        const selectedPostContent = document.getElementById('posts').selectedOptions[0].textContent;

        const postUrl = `http://localhost:3030/jsonstore/blog/posts/${selectedPostId}`;
        const commentsUrl = 'http://localhost:3030/jsonstore/blog/comments';

        postTitle.textContent = selectedPostContent;
        postBody.textContent = '';
        postComments.innerHTML = '';

        try {
            const [postResponse, commentsResponse] = await Promise.all([
                fetch(postUrl),
                fetch(commentsUrl)
            ]);

            if (!postResponse.ok || !commentsResponse.ok) {
                throw new Error('Error fetching post or comments');
            }

            const postData = await postResponse.json();
            const commentsData = await commentsResponse.json();

            postBody.textContent = postData.body;

            Object.values(commentsData).forEach(comment => {
                if (comment.postId === selectedPostId) {
                    const li = document.createElement('li');
                    li.textContent = comment.text;
                    postComments.appendChild(li);
                }
            });
        } catch (error) {
            console.error('Failed to load post details:', error);
        }
    });
}

attachEvents();
