function attachEvents()
{
    const loadPostsButton = document.getElementById('btnLoadPosts');
    loadPostsButton.addEventListener('click', async () =>
    {
        const selectPosts = document.getElementById('posts');
        const postsUrl = 'http://localhost:3030/jsonstore/blog/posts';

        selectPosts.innerHTML = '';

        try
        {
            const response = await fetch(postsUrl);
            if (!response.ok)
            {
                throw new Error('Error fetching data');
            }

            const postsData = await response.json();

            Object.values(postsData).forEach(postData =>
            {
                const optionElement = document.createElement('option');
                optionElement.id = postData.id;
                optionElement.textContent = postData.title;
                selectPosts.appendChild(optionElement);
            });
        }
        catch (error)
        {
            //stopNameDiv.textContent = 'Error';
        }
    });

    const viewPostsButton = document.getElementById('btnViewPost');
    viewPostsButton.addEventListener('click', async () =>
    {
        const postTitle = document.getElementById('post-title');
        const commentsUrl = 'http://localhost:3030/jsonstore/blog/comments';
        const selectedPostContent = document.getElementById('posts').value;
        const selectedPostId = document.getElementById('posts').selectedOptions[0].id;
        const postBody = document.getElementById('post-body');
        const postComments = document.getElementById('post-comments');

        postTitle.textContent = selectedPostContent;
        postComments.innerHTML = '';

        try
        {
            const commentsResponse = await fetch(commentsUrl);
            const postResponse = await fetch(`http://localhost:3030/jsonstore/blog/posts/${selectedPostId}`);
            if (!commentsResponse.ok || !postResponse.ok)
            {
                throw new Error('Error fetching data');
            }

            const commentsData = await commentsResponse.json();
            const postData = await postResponse.json();

            postBody.textContent = postData.body;

            Object.values(commentsData).forEach(commentData =>
            {
                if(postData.id === commentData.postId)
                {
                    const liElement = document.createElement('li');
                    liElement.textContent = commentData.text;
                    postComments.appendChild(liElement);
                }
            });
        }
        catch (error)
        {
            //postTitle.textContent = 'Error';
        }
    });
}

attachEvents();